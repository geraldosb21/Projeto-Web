<h2>Raça Angus</h2>
<p>A raça Angus é originária da Escócia e é famosa pela sua carne de excelente qualidade, com ótimo marmoreio e sabor. Os bovinos Angus são adaptáveis e possuem um rápido ganho de peso, sendo uma das raças mais populares para pecuária de corte.</p>
<img src="img/angus.jpg" alt="Gado Angus" style="max-width:100%; height:auto; border-radius: 8px;">
<a href="index.php" style="display: inline-block; margin-top: 20px;">Voltar para a Página Inicial</a>
