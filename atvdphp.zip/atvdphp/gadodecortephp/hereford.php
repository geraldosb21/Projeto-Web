<h2>Raça Hereford</h2>
<p>A raça Hereford é originária da Inglaterra e se destaca por sua carne de alta qualidade e rendimento, com excelente marmoreio e maciez. São animais de temperamento dócil e fácil manejo, sendo uma escolha popular em cruzamentos para melhoramento genético.</p>
<img src="img/hereford.jpg" alt="Gado Hereford" style="max-width:100%; height:auto; border-radius: 8px;">
<a href="index.php" style="display: inline-block; margin-top: 20px;">Voltar para a Página Inicial</a>

