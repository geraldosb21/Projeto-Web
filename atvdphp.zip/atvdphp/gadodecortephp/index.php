<?php
// Define a página padrão como 'principal'
$page = $_GET['page'] ?? 'principal';
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Portal de Raças de Gado de Corte</title>
    <link rel="stylesheet" href="style.css">  <!-- Inclusão do CSS -->
</head>
<body>
<header>
    <div class="header-content">
    <img src="img/portal.jpg" alt="Logo do Site" class="logo"> <!-- Imagem ao lado do título -->
    <h1>Portal de Raças de Gado de Corte</h1>
    <nav>
        <a href="index.php?page=principal">Início</a>
        <a href="index.php?page=quemsomos">Quem Somos</a>
        <a href="index.php?page=clientes">Clientes</a>
        <a href="index.php?page=faleconosco">Fale Conosco</a>
    </nav>
</header>
<div class="container">
    <?php
    // Inclui a página com base no parâmetro 'page'
    if (file_exists("$page.php")) {
        include("$page.php");
    } else {
        echo "<h2>Página não encontrada!</h2>";
        echo "<p>A página solicitada não existe.</p>";
    }
    ?>
</div>
<footer>
    <p>&copy; 2024 Portal de Raças de Gado de Corte. Todos os direitos reservados.</p>
</footer>
</body>
</html>