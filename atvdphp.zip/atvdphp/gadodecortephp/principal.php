<h2>Bem-vindo ao Portal de Raças de Gado de Corte</h2>
<p>Este portal é dedicado a fornecer informações sobre as principais raças de gado de corte utilizadas na pecuária moderna. Explore mais sobre cada raça e suas características específicas.</p>
<ul>
    <li><a href="index.php?page=angus">Raça Angus</a></li>
    <li><a href="index.php?page=nelore">Raça Nelore</a></li>
    <li><a href="index.php?page=hereford">Raça Hereford</a></li>
</ul>
<div style="display: flex; justify-content: space-around; margin-top: 20px;">
    <div>
        <h3>Raça Angus</h3>
        <img src="img/angus.jpg" alt="Raça Angus" style="width: 200px; height: 150px;">
    </div>
    <div>
        <h3>Raça Nelore</h3>
        <img src="img/nelore.jpg" alt="Raça Nelore" style="width: 200px; height: 150px;">
    </div>
    <div>
        <h3>Raça Hereford</h3>
        <img src="img/hereford.jpg" alt="Raça Hereford" style="width: 200px; height: 150px;">
    </div>
</div>
