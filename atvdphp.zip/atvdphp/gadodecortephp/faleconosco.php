<h2>Fale Conosco</h2>
<p>Entre em contato para saber mais sobre as raças de gado de corte ou compartilhar sua experiência conosco:</p>
<form action="faleconosco.php" method="post">
    <label for="nome">Nome:</label><br>
    <input type="text" id="nome" name="nome" required><br><br>
    
    <label for="email">Email:</label><br>
    <input type="email" id="email" name="email" required><br><br>
    
    <label for="mensagem">Mensagem:</label><br>
    <textarea id="mensagem" name="mensagem" rows="5" required></textarea><br><br>
    
    <input type="submit" value="Enviar">
</form>

<?php
// Processamento básico do formulário de contato
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nome = htmlspecialchars($_POST['nome']);
    $email = htmlspecialchars($_POST['email']);
    $mensagem = htmlspecialchars($_POST['mensagem']);
    
    echo "<p>Obrigado, <strong>$nome</strong>! Sua mensagem foi enviada com sucesso.</p>";
}
?>