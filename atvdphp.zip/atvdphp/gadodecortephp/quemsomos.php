<h2>Quem Somos</h2>
<p>Somos um portal informativo dedicado a compartilhar conhecimento sobre as principais raças de gado de corte. Nossa missão é fornecer informações claras e objetivas para criadores, produtores e entusiastas da pecuária.</p>
<img src="img/portal.jpg" alt="Raça Nelore" style="width: 300px; height: 250px;">