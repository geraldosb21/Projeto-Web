<h2>Raça Nelore</h2>
<p>O Nelore é uma raça de origem indiana, muito popular no Brasil devido à sua resistência a climas quentes e sua habilidade de se adaptar a diferentes regiões. É a principal raça utilizada na pecuária de corte brasileira, sendo valorizada pelo rápido crescimento e eficiência alimentar.</p>
<img src="img/nelore.jpg" alt="Gado Nelore" style="max-width:100%; height:auto; border-radius: 8px;">
<a href="index.php" style="display: inline-block; margin-top: 20px;">Voltar para a Página Inicial</a>

